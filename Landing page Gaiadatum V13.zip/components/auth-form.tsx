'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { authClient } from '@/lib/auth-client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card } from '@/components/ui/card'

export function AuthForm({ mode }: { mode: 'sign-in' | 'sign-up' }) {
  const router = useRouter()
  const isSignUp = mode === 'sign-up'
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setLoading(true)
    const result = isSignUp
      ? await authClient.signUp.email({ name, email, password })
      : await authClient.signIn.email({ email, password })
    setLoading(false)
    if (result.error) {
      setError('No pudimos completar la solicitud. Verifica tus datos e inténtalo de nuevo.')
      return
    }
    router.push('/perfil')
    router.refresh()
  }

  return (
    <main className="flex min-h-svh items-center justify-center bg-background px-4 py-12">
      <Card className="w-full max-w-md border-border bg-card p-6 shadow-xl sm:p-8">
        <div className="mb-6">
          <p className="text-sm font-medium text-primary">GaiaDatum</p>
          <h1 className="mt-2 text-2xl font-semibold text-foreground">{isSignUp ? 'Crea tu cuenta' : 'Bienvenido de nuevo'}</h1>
          <p className="mt-2 text-sm text-muted-foreground">{isSignUp ? 'Guarda tus análisis y lleva el control de tus servicios.' : 'Inicia sesión para consultar tu historial.'}</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && <div className="space-y-2"><Label htmlFor="name">Nombre</Label><Input id="name" value={name} onChange={(e) => setName(e.target.value)} required autoComplete="name" /></div>}
          <div className="space-y-2"><Label htmlFor="email">Correo electrónico</Label><Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" /></div>
          <div className="space-y-2"><Label htmlFor="password">Contraseña</Label><Input id="password" type="password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required autoComplete={isSignUp ? 'new-password' : 'current-password'} /></div>
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
          <Button className="w-full" disabled={loading}>{loading ? 'Procesando…' : isSignUp ? 'Registrarme' : 'Iniciar sesión'}</Button>
        </form>
        <p className="mt-6 text-center text-sm text-muted-foreground">{isSignUp ? '¿Ya tienes una cuenta? ' : '¿Aún no tienes cuenta? '}<Link className="font-medium text-primary hover:underline" href={isSignUp ? '/iniciar-sesion' : '/registrarse'}>{isSignUp ? 'Inicia sesión' : 'Regístrate'}</Link></p>
      </Card>
    </main>
  )
}
