"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X, Leaf, Mail, User } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import { useSession } from "@/lib/auth-client"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"

const teamMembers = [
  { name: "Jaider Gallego", email: "jhonjaider2466@gmail.com" },
  { name: "Samuel Herrera", email: "samuelherrera24agudelo@gmail.com" },
  { name: "Samuel Villa", email: "Cocosamuelcocovilla@gmail.com" },
]

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [showMobileContact, setShowMobileContact] = useState(false)
  const { data: session } = useSession()

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <Leaf className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold text-foreground">GaiaDatum</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link href="#desafio" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Desafio
          </Link>
          <Link href="#solucion" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Solucion
          </Link>
          <Link href="#caracteristicas" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Caracteristicas
          </Link>
          <Link href="#impacto" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Impacto
          </Link>
        </nav>

        <div className="hidden items-center gap-4 md:flex">
          <ThemeToggle />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2 border-primary/40 text-foreground hover:bg-primary/10">
                <User className="h-4 w-4" />
                {session?.user ? session.user.name : 'Usuario'}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              {session?.user ? (
                <>
                  <DropdownMenuLabel>Mi cuenta</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild><Link href="/perfil">Perfil e historial</Link></DropdownMenuItem>
                </>
              ) : (
                <>
                  <DropdownMenuLabel>Accede a GaiaDatum</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild><Link href="/iniciar-sesion">Iniciar sesión</Link></DropdownMenuItem>
                  <DropdownMenuItem asChild><Link href="/registrarse">Registrarse</Link></DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="text-muted-foreground hover:text-foreground">
                Contacto
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64">
              <DropdownMenuLabel>Seleccione el miembro del equipo</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {teamMembers.map((member) => (
                <DropdownMenuItem key={member.email} asChild>
                  <a
                    href={`mailto:${member.email}`}
                    className="flex cursor-pointer items-center gap-2"
                  >
                    <Mail className="h-4 w-4" />
                    {member.name}
                  </a>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <Link href="/calculadora">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              Comenzar
            </Button>
          </Link>
        </div>

        <button
          className="md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? (
            <X className="h-6 w-6 text-foreground" />
          ) : (
            <Menu className="h-6 w-6 text-foreground" />
          )}
        </button>
      </div>

      {isMenuOpen && (
        <div className="border-t border-border bg-background md:hidden">
          <nav className="flex flex-col gap-4 px-4 py-6">
            <Link
              href="#desafio"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              onClick={() => setIsMenuOpen(false)}
            >
              Desafio
            </Link>
            <Link
              href="#solucion"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              onClick={() => setIsMenuOpen(false)}
            >
              Solucion
            </Link>
            <Link
              href="#caracteristicas"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              onClick={() => setIsMenuOpen(false)}
            >
              Caracteristicas
            </Link>
            <Link
              href="#impacto"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              onClick={() => setIsMenuOpen(false)}
            >
              Impacto
            </Link>
            <div className="flex flex-col gap-2 pt-4">
              <div className="flex items-center justify-between px-2">
                <span className="text-sm text-muted-foreground">Cambiar tema</span>
                <ThemeToggle />
              </div>
              
              {/* Contact Section Mobile */}
              <div className="mt-2">
                <button
                  onClick={() => setShowMobileContact(!showMobileContact)}
                  className="w-full rounded-md px-3 py-2 text-left text-sm text-muted-foreground hover:bg-secondary hover:text-foreground"
                >
                  Contacto
                </button>
                {showMobileContact && (
                  <div className="mt-2 space-y-1 rounded-lg bg-secondary/50 p-3">
                    <p className="mb-2 text-xs text-muted-foreground">Seleccione el miembro del equipo:</p>
                    {teamMembers.map((member) => (
                      <a
                        key={member.email}
                        href={`mailto:${member.email}`}
                        className="flex items-center gap-2 rounded-md px-2 py-2 text-sm text-foreground hover:bg-secondary"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <Mail className="h-4 w-4 text-primary" />
                        {member.name}
                      </a>
                    ))}
                  </div>
                )}
              </div>

              <Link href="/calculadora" onClick={() => setIsMenuOpen(false)}>
                <Button className="w-full bg-primary text-primary-foreground">
                  Comenzar
                </Button>
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
