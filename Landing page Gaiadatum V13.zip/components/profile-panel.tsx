'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Leaf, LogOut, ArrowLeft, CalendarDays, ReceiptText } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { authClient } from '@/lib/auth-client'

type Analysis = {
  id: string
  month: string
  year: number
  estrato: number
  totalCost: number
  totalCo2: number
  createdAt: Date | string
  selectedServices: unknown
}

const serviceLabels: Record<string, string> = {
  energia: 'Energía',
  gas: 'Gas',
  agua: 'Acueducto',
  alcantarillado: 'Alcantarillado',
}

function formatCurrency(value: number) {
  return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(value)
}

function formatDate(value: Date | string) {
  return new Intl.DateTimeFormat('es-CO', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(value))
}

export function ProfilePanel({ user, analyses }: { user: { name: string; email: string }; analyses: Analysis[] }) {
  const router = useRouter()

  async function handleSignOut() {
    await authClient.signOut()
    router.push('/')
    router.refresh()
  }

  return (
    <main className="min-h-svh bg-background px-4 py-10">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-semibold text-foreground">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <Leaf className="h-5 w-5 text-primary-foreground" />
            </span>
            GaiaDatum
          </Link>
          <Button variant="outline" onClick={handleSignOut}>
            <LogOut className="mr-2 h-4 w-4" />Cerrar sesión
          </Button>
        </div>

        <Card className="border-border bg-card p-6 sm:p-8">
          <p className="text-sm font-medium text-primary">Mi cuenta</p>
          <h1 className="mt-2 text-3xl font-semibold text-foreground">Hola, {user.name}</h1>
          <p className="mt-2 text-muted-foreground">{user.email}</p>

          <section className="mt-8" aria-labelledby="history-heading">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h2 id="history-heading" className="font-semibold text-foreground">Historial de análisis</h2>
                <p className="mt-1 text-sm text-muted-foreground">Tus facturas y consumos guardados aparecen aquí.</p>
              </div>
              <ReceiptText className="hidden h-6 w-6 text-primary sm:block" />
            </div>

            {analyses.length === 0 ? (
              <div className="mt-5 rounded-xl border border-dashed border-border bg-secondary/40 p-6 text-center">
                <p className="text-sm text-muted-foreground">Todavía no tienes análisis guardados.</p>
                <Link href="/calculadora" className="mt-4 inline-block">
                  <Button><ArrowLeft className="mr-2 h-4 w-4" />Ir a la calculadora</Button>
                </Link>
              </div>
            ) : (
              <div className="mt-5 space-y-4">
                {analyses.map((analysis) => {
                  const selected = Object.entries((analysis.selectedServices ?? {}) as Record<string, boolean>)
                    .filter(([, enabled]) => enabled)
                    .map(([service]) => serviceLabels[service] ?? service)
                    .join(' · ')

                  return (
                    <article key={analysis.id} className="rounded-xl border border-border bg-secondary/30 p-5">
                      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
                        <div>
                          <p className="flex items-center gap-2 font-semibold text-foreground">
                            <CalendarDays className="h-4 w-4 text-primary" />
                            Análisis del día {formatDate(analysis.createdAt)}
                          </p>
                          <p className="mt-1 text-sm text-muted-foreground">
                            Periodo: {analysis.month} {analysis.year} · Estrato {analysis.estrato}
                          </p>
                        </div>
                        <div className="text-left sm:text-right">
                          <p className="text-lg font-semibold text-primary">{formatCurrency(analysis.totalCost)}</p>
                          <p className="text-xs text-muted-foreground">Costo mensual estimado</p>
                        </div>
                      </div>
                      <div className="mt-4 grid gap-3 border-t border-border pt-4 text-sm sm:grid-cols-3">
                        <div><p className="text-muted-foreground">Servicios</p><p className="mt-1 font-medium text-foreground">{selected || 'No especificados'}</p></div>
                        <div><p className="text-muted-foreground">CO₂ estimado</p><p className="mt-1 font-medium text-foreground">{analysis.totalCo2.toFixed(2)} kg</p></div>
                        <div><p className="text-muted-foreground">Guardado</p><p className="mt-1 font-medium text-foreground">{formatDate(analysis.createdAt)}</p></div>
                      </div>
                    </article>
                  )
                })}
              </div>
            )}
          </section>
        </Card>
      </div>
    </main>
  )
}
