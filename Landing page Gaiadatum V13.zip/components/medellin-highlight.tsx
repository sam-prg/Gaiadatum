import { MapPin, ShieldCheck, Sparkles } from "lucide-react"

export function MedellinHighlight() {
  return (
    <section className="border-y border-primary/15 bg-primary/5 py-12">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 sm:px-6 lg:flex-row lg:items-center lg:justify-between lg:px-8">
        <div className="flex items-start gap-4">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary">
            <MapPin className="h-5 w-5" aria-hidden="true" />
          </div>
          <div>
            <p className="mb-1 flex items-center gap-2 text-sm font-medium text-primary">
              <Sparkles className="h-4 w-4" aria-hidden="true" />
              Actualización de tarifas
            </p>
            <h2 className="text-xl font-semibold text-foreground sm:text-2xl">Datos oficiales para Medellín</h2>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
              La calculadora usa las tarifas EPM de septiembre de 2026 para hogares de Medellín. Así obtienes una estimación más precisa y no mezclas valores de otros municipios del área metropolitana.
            </p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2 rounded-full border border-primary/20 bg-background/60 px-4 py-2 text-sm text-muted-foreground">
          <ShieldCheck className="h-4 w-4 text-primary" aria-hidden="true" />
          EPM · Medellín
        </div>
      </div>
    </section>
  )
}
