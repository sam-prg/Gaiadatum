"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Zap, Leaf, BarChart3 } from "lucide-react"
import Link from "next/link"

export function HeroSection() {
  return (
    <section className="relative min-h-screen overflow-hidden pt-16">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute left-1/4 top-1/4 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 h-96 w-96 rounded-full bg-accent/10 blur-3xl" />
      </div>

      <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-7xl flex-col items-center justify-center px-4 py-20 sm:px-6 lg:px-8">
        <div className="mb-8 flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2">
          <Leaf className="h-4 w-4 text-primary" />
          <span className="text-sm text-primary">Sistema Inteligente de Sostenibilidad</span>
        </div>

        <h1 className="max-w-4xl text-balance text-center text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl lg:text-7xl">
          Monitoreo energético inteligente para un{" "}
          <span className="text-primary">futuro sostenible</span>
        </h1>

        <p className="mt-6 max-w-2xl text-pretty text-center text-lg text-muted-foreground sm:text-xl">
          Plataforma que integra sensores IoT y análisis de datos para monitorear el consumo 
          energético en tiempo real y calcular tu huella de carbono.
        </p>

        <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row">
          <Link href="/calculadora">
            <Button size="lg" className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
              Comenzar ahora
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <Button size="lg" variant="outline" className="gap-2 border-border text-foreground hover:bg-secondary">
            Ver demostracion
          </Button>
        </div>

        {/* Stats */}
        <div className="mt-20 grid w-full max-w-4xl grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="flex flex-col items-center rounded-xl border border-border bg-card/50 p-6 backdrop-blur-sm">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20">
              <Zap className="h-6 w-6 text-primary" />
            </div>
            <span className="text-3xl font-bold text-foreground">Tiempo Real</span>
            <span className="mt-1 text-sm text-muted-foreground">Monitoreo continuo</span>
          </div>
          <div className="flex flex-col items-center rounded-xl border border-border bg-card/50 p-6 backdrop-blur-sm">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-lg bg-accent/20">
              <Leaf className="h-6 w-6 text-accent" />
            </div>
            <span className="text-3xl font-bold text-foreground">CO₂</span>
            <span className="mt-1 text-sm text-muted-foreground">Cálculo de huella</span>
          </div>
          <div className="flex flex-col items-center rounded-xl border border-border bg-card/50 p-6 backdrop-blur-sm">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-lg bg-chart-3/20">
              <BarChart3 className="h-6 w-6 text-chart-3" />
            </div>
            <span className="text-3xl font-bold text-foreground">IoT</span>
            <span className="mt-1 text-sm text-muted-foreground">Sensores integrados</span>
          </div>
        </div>
      </div>
    </section>
  )
}
