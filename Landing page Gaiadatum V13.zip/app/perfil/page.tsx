import { redirect } from 'next/navigation'
import { headers } from 'next/headers'
import { auth } from '@/lib/auth'
import { getConsumptionAnalyses } from '@/app/actions/consumption'
import { ProfilePanel } from '@/components/profile-panel'

export default async function ProfilePage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect('/iniciar-sesion')
  const analyses = await getConsumptionAnalyses()
  return <ProfilePanel user={session.user} analyses={analyses} />
}
