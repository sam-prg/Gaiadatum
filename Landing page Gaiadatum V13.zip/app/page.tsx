import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { ChallengeSection } from "@/components/challenge-section"
import { SolutionSection } from "@/components/solution-section"
import { FeaturesSection } from "@/components/features-section"
import { ImpactSection } from "@/components/impact-section"
import { CTASection } from "@/components/cta-section"
import { Footer } from "@/components/footer"
import { MedellinHighlight } from "@/components/medellin-highlight"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <MedellinHighlight />
        <ChallengeSection />
        <SolutionSection />
        <FeaturesSection />
        <ImpactSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  )
}
