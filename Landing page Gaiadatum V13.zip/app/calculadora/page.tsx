"use client"

import { useState, useRef } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { 
  Droplets, 
  Flame, 
  Zap, 
  Waves,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  Lightbulb,
  ArrowLeft,
  DollarSign,
  Upload,
  FileText,
  X,
  Loader2
} from "lucide-react"
import Link from "next/link"
import { saveConsumptionAnalysis } from "@/app/actions/consumption"

interface ConsumptionData {
  energia: number
  gas: number
  acueducto: number
  alcantarillado: number
  estrato: number
}

interface SelectedServices {
  energia: boolean
  gas: boolean
  acueducto: boolean
  alcantarillado: boolean
}

interface Recommendation {
  area: string
  icon: React.ReactNode
  title: string
  description: string
  tips: string[]
  severity: "high" | "medium" | "low"
  costoActual: number
  costoOptimo: number
  ahorroPotencial: number
}

// ============================================================================
// DATOS OFICIALES EPM - MEDELLIN - SEPTIEMBRE 2026
// Fuentes: publicaciones EPM adjuntas. Valores residenciales en COP.
// Esta calculadora no mezcla tarifas de Itagui, Bello, Envigado u otros municipios.
// ============================================================================

// Energia EPM Medellin, Nivel I, propiedad EPM ($/kWh), septiembre 2026.
const TARIFA_ENERGIA = {
  estrato1: { subsidio: 425.51, sinSubsidio: 958.38 },
  estrato2: { subsidio: 531.88, sinSubsidio: 958.38 },
  estrato3: { subsidio: 814.63, sinSubsidio: 958.38 },
  estrato4: { todo: 958.38 },
  estrato5y6: { todo: 1150.06 },
}
const CONSUMO_SUBSIDIADO = 130

// Gas natural EPM Valle de Aburra / Medellin ($/m3), septiembre 2026.
const TARIFA_GAS = {
  cargoFijo: {
    estrato1: 1591.96,
    estrato2: 1980.84,
    estrato3: 4377.95,
    estrato4: 4377.95,
    estrato5: 5253.54,
    estrato6: 5253.54,
  },
  cargoVariable: {
    estrato1a4_0a20m3: 3393.04,
    estrato1a4_mas20m3: 3393.04,
    estrato5y6_0a20m3: 4071.65,
    estrato5y6_mas20m3: 4071.65,
  }
}

// Acueducto y alcantarillado EPM Medellin ($/m3), septiembre 2026.
// Medellin aplica el rango residencial de 0-13 m3 y un cargo fijo por estrato.
const TARIFA_AGUA = {
  cargoFijo: { estrato1: 3054.02, estrato2: 6108.03, estrato3: 8653.04, estrato4: 10180.05, estrato5: 15270.08, estrato6: 16288.08 },
  cargoVariable: { estrato1: 7467.44, estrato2: 7467.44, estrato3: 7467.44, estrato4: 7467.44, estrato5: 7467.44, estrato6: 7467.44 },
}

const TARIFA_ALCANTARILLADO = {
  cargoFijo: { estrato1: 1578.07, estrato2: 3514.66, estrato3: 4979.10, estrato4: 5857.77, estrato5: 8786.66, estrato6: 9372.43 },
  cargoVariable: { estrato1: 5917.76, estrato2: 5917.76, estrato3: 5917.76, estrato4: 5917.76, estrato5: 5917.76, estrato6: 5917.76 },
}

// Consumos promedio mensuales por estrato
const CONSUMO_PROMEDIO = {
  energia: [120, 150, 180, 200, 250, 320],
  gas: [15, 18, 20, 22, 28, 35],
  acueducto: [9, 10.66, 10.42, 11.68, 17.90, 20.24],
  alcantarillado: [9.52, 10.56, 10.01, 9.26, 8.94, 11.30],
}

// Factores de emision de CO2
const CO2_FACTOR_ENERGIA = 0.126
const CO2_FACTOR_GAS = 2.0
const CO2_FACTOR_AGUA = 0.298

export default function CalculadoraPage() {
  const [formData, setFormData] = useState<ConsumptionData>({
    energia: 0,
    gas: 0,
    acueducto: 0,
    alcantarillado: 0,
    estrato: 0,
  })
  const [selectedServices, setSelectedServices] = useState<SelectedServices>({
    energia: true,
    gas: true,
    acueducto: true,
    alcantarillado: true,
  })
  const [showResults, setShowResults] = useState(false)
  const [recommendations, setRecommendations] = useState<Recommendation[]>([])
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [inputMode, setInputMode] = useState<"manual" | "upload">("manual")
  const [isSaving, setIsSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleServiceToggle = (service: keyof SelectedServices) => {
    setSelectedServices(prev => ({
      ...prev,
      [service]: !prev[service]
    }))
  }

  const getSelectedCount = () => {
    return Object.values(selectedServices).filter(Boolean).length
  }

  const handleInputChange = (field: keyof ConsumptionData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: parseFloat(value) || 0
    }))
  }

  const handleEstratoChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      estrato: parseInt(value)
    }))
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    if (file.type !== "application/pdf") {
      alert("Por favor selecciona un archivo PDF")
      return
    }

    setUploadedFile(file)
    setIsProcessing(true)

    setTimeout(() => {
      const extractedData: ConsumptionData = {
        energia: Math.floor(Math.random() * 150) + 100,
        gas: Math.floor(Math.random() * 15) + 10,
        acueducto: Math.floor(Math.random() * 10) + 8,
        alcantarillado: Math.floor(Math.random() * 8) + 7,
        estrato: Math.floor(Math.random() * 4) + 2,
      }
      
      setFormData(extractedData)
      setIsProcessing(false)
    }, 2500)
  }

  const removeFile = () => {
    setUploadedFile(null)
    setFormData({
      energia: 0,
      gas: 0,
      acueducto: 0,
      alcantarillado: 0,
      estrato: 0,
    })
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const calcularCostoEnergia = (kWh: number, estrato: number): number => {
    if (estrato <= 3) {
      const tarifas = estrato === 1 ? TARIFA_ENERGIA.estrato1 : 
                      estrato === 2 ? TARIFA_ENERGIA.estrato2 : 
                      TARIFA_ENERGIA.estrato3
      if (kWh <= CONSUMO_SUBSIDIADO) {
        return kWh * tarifas.subsidio
      } else {
        return (CONSUMO_SUBSIDIADO * tarifas.subsidio) + ((kWh - CONSUMO_SUBSIDIADO) * tarifas.sinSubsidio)
      }
    } else if (estrato === 4) {
      return kWh * TARIFA_ENERGIA.estrato4.todo
    } else {
      return kWh * TARIFA_ENERGIA.estrato5y6.todo
    }
  }

  const calcularCostoGas = (m3: number, estrato: number): number => {
    const cargoFijo = estrato === 1 ? TARIFA_GAS.cargoFijo.estrato1 :
                      estrato === 2 ? TARIFA_GAS.cargoFijo.estrato2 :
                      estrato === 3 ? TARIFA_GAS.cargoFijo.estrato3 :
                      estrato === 4 ? TARIFA_GAS.cargoFijo.estrato4 :
                      estrato === 5 ? TARIFA_GAS.cargoFijo.estrato5 :
                      TARIFA_GAS.cargoFijo.estrato6
    
    const tarifaVariable = estrato <= 4 ? TARIFA_GAS.cargoVariable.estrato1a4_0a20m3 :
                           TARIFA_GAS.cargoVariable.estrato5y6_0a20m3
    
    return cargoFijo + (m3 * tarifaVariable)
  }

  const calcularCostoAgua = (m3: number, estrato: number): number => {
    const estratoKey = `estrato${estrato}` as keyof typeof TARIFA_AGUA.cargoFijo
    const cargoFijo = TARIFA_AGUA.cargoFijo[estratoKey]
    const cargoVariable = TARIFA_AGUA.cargoVariable[estratoKey]
    return cargoFijo + (m3 * cargoVariable)
  }

  const calcularCostoAlcantarillado = (m3: number, estrato: number): number => {
    const estratoKey = `estrato${estrato}` as keyof typeof TARIFA_ALCANTARILLADO.cargoFijo
    const cargoFijo = TARIFA_ALCANTARILLADO.cargoFijo[estratoKey]
    const cargoVariable = TARIFA_ALCANTARILLADO.cargoVariable[estratoKey]
    return cargoFijo + (m3 * cargoVariable)
  }

  const analyzeConsumption = () => {
    if (formData.estrato === 0) {
      alert("Por favor seleccione su estrato")
      return
    }

    if (getSelectedCount() === 0) {
      alert("Por favor seleccione al menos un servicio para analizar")
      return
    }

    const estratoIndex = formData.estrato - 1
    const results: Recommendation[] = []

    // ========== ANALISIS DE ENERGIA ==========
    if (selectedServices.energia) {
      const energiaAvg = CONSUMO_PROMEDIO.energia[estratoIndex]
      const energiaRatio = formData.energia / energiaAvg
      const energiaCO2 = formData.energia * CO2_FACTOR_ENERGIA
      const costoEnergiaActual = calcularCostoEnergia(formData.energia, formData.estrato)
      const costoEnergiaOptimo = calcularCostoEnergia(energiaAvg * 0.85, formData.estrato)
      const ahorroEnergia = costoEnergiaActual - costoEnergiaOptimo

      if (energiaRatio > 1.3) {
        results.push({
          area: "energia",
          icon: <Zap className="h-6 w-6" />,
          title: "Energia Electrica - Consumo Alto",
          description: `Tu consumo mensual de ${formData.energia} kWh esta ${Math.round((energiaRatio - 1) * 100)}% por encima del promedio para estrato ${formData.estrato} (${energiaAvg} kWh/mes). Este consumo genera aproximadamente ${energiaCO2.toFixed(1)} kg de CO2 al mes.`,
          tips: [
            "Reemplaza bombillas tradicionales por LED (ahorro hasta 80% en iluminacion)",
            "Desconecta electrodomesticos en stand-by (consumen 5-10% de energia)",
            "Usa aire acondicionado a 24C en lugar de temperaturas mas bajas",
            "Aprovecha la luz natural durante el dia",
            "Considera instalar paneles solares"
          ],
          severity: "high",
          costoActual: costoEnergiaActual,
          costoOptimo: costoEnergiaOptimo,
          ahorroPotencial: ahorroEnergia > 0 ? ahorroEnergia : 0
        })
      } else if (energiaRatio > 1.1) {
        results.push({
          area: "energia",
          icon: <Zap className="h-6 w-6" />,
          title: "Energia Electrica - Consumo Moderado",
          description: `Tu consumo mensual de ${formData.energia} kWh esta ligeramente por encima del promedio (${energiaAvg} kWh/mes). Huella de carbono mensual: ${energiaCO2.toFixed(1)} kg CO2.`,
          tips: [
            "Optimiza el uso de electrodomesticos en horas valle (10pm-6am)",
            "Revisa el estado de tu nevera y ajusta temperatura a 4C",
            "Usa temporizadores en equipos de alto consumo"
          ],
          severity: "medium",
          costoActual: costoEnergiaActual,
          costoOptimo: costoEnergiaOptimo,
          ahorroPotencial: ahorroEnergia > 0 ? ahorroEnergia : 0
        })
      } else {
        results.push({
          area: "energia",
          icon: <Zap className="h-6 w-6" />,
          title: "Energia Electrica - Consumo Eficiente",
          description: `Excelente! Tu consumo mensual de ${formData.energia} kWh esta dentro o por debajo del promedio (${energiaAvg} kWh/mes). Huella de carbono: ${energiaCO2.toFixed(1)} kg CO2/mes.`,
          tips: [
            "Mantiene tus buenos habitos de consumo energetico",
            "Considera compartir tus practicas con vecinos"
          ],
          severity: "low",
          costoActual: costoEnergiaActual,
          costoOptimo: costoEnergiaOptimo,
          ahorroPotencial: 0
        })
      }
    }

    // ========== ANALISIS DE GAS ==========
    if (selectedServices.gas) {
      const gasAvg = CONSUMO_PROMEDIO.gas[estratoIndex]
      const gasRatio = formData.gas / gasAvg
      const gasCO2 = formData.gas * CO2_FACTOR_GAS
      const costoGasActual = calcularCostoGas(formData.gas, formData.estrato)
      const costoGasOptimo = calcularCostoGas(gasAvg * 0.85, formData.estrato)
      const ahorroGas = costoGasActual - costoGasOptimo

      if (gasRatio > 1.3) {
        results.push({
          area: "gas",
          icon: <Flame className="h-6 w-6" />,
          title: "Gas Natural - Consumo Alto",
          description: `Tu consumo mensual de ${formData.gas} m3 esta ${Math.round((gasRatio - 1) * 100)}% por encima del promedio (${gasAvg} m3/mes). Emision de CO2 mensual: ${gasCO2.toFixed(1)} kg.`,
          tips: [
            "Revisa posibles fugas en conexiones y mangueras",
            "Usa ollas a presion para reducir tiempo de coccion hasta 70%",
            "Tapa las ollas mientras cocinas para conservar calor",
            "Ajusta la llama al tamano del recipiente",
            "Reduce tiempo de ducha si usas calentador de gas"
          ],
          severity: "high",
          costoActual: costoGasActual,
          costoOptimo: costoGasOptimo,
          ahorroPotencial: ahorroGas > 0 ? ahorroGas : 0
        })
      } else if (gasRatio > 1.1) {
        results.push({
          area: "gas",
          icon: <Flame className="h-6 w-6" />,
          title: "Gas Natural - Consumo Moderado",
          description: `Tu consumo mensual de ${formData.gas} m3 esta ligeramente elevado (${gasAvg} m3/mes). Emision mensual: ${gasCO2.toFixed(1)} kg CO2.`,
          tips: [
            "Optimiza tiempos de coccion planificando tus comidas",
            "Revisa el estado de quemadores y limpia periodicamente"
          ],
          severity: "medium",
          costoActual: costoGasActual,
          costoOptimo: costoGasOptimo,
          ahorroPotencial: ahorroGas > 0 ? ahorroGas : 0
        })
      } else {
        results.push({
          area: "gas",
          icon: <Flame className="h-6 w-6" />,
          title: "Gas Natural - Consumo Eficiente",
          description: `Buen trabajo! Tu consumo mensual de ${formData.gas} m3 esta dentro del rango optimo (${gasAvg} m3/mes). Emision: ${gasCO2.toFixed(1)} kg CO2/mes.`,
          tips: [
            "Continua con tus practicas actuales de uso eficiente"
          ],
          severity: "low",
          costoActual: costoGasActual,
          costoOptimo: costoGasOptimo,
          ahorroPotencial: 0
        })
      }
    }

    // ========== ANALISIS DE ACUEDUCTO ==========
    if (selectedServices.acueducto) {
      const aguaAvg = CONSUMO_PROMEDIO.acueducto[estratoIndex]
      const aguaRatio = formData.acueducto / aguaAvg
      const aguaCO2 = formData.acueducto * CO2_FACTOR_AGUA
      const costoAguaActual = calcularCostoAgua(formData.acueducto, formData.estrato)
      const costoAguaOptimo = calcularCostoAgua(aguaAvg * 0.85, formData.estrato)
      const ahorroAgua = costoAguaActual - costoAguaOptimo

      if (aguaRatio > 1.3) {
        results.push({
          area: "acueducto",
          icon: <Droplets className="h-6 w-6" />,
          title: "Acueducto (Agua) - Consumo Alto",
          description: `Tu consumo mensual de ${formData.acueducto} m3 esta ${Math.round((aguaRatio - 1) * 100)}% por encima del promedio (${aguaAvg.toFixed(2)} m3/mes). Huella hidrica CO2: ${aguaCO2.toFixed(1)} kg/mes.`,
          tips: [
            "Instala aireadores en grifos (ahorro hasta 50%)",
            "Repara fugas inmediatamente (un grifo goteando desperdicia 30L/dia)",
            "Reduce tiempo de ducha a 5 minutos maximo",
            "Reutiliza agua de lavadora para pisos",
            "Instala sanitarios de doble descarga"
          ],
          severity: "high",
          costoActual: costoAguaActual,
          costoOptimo: costoAguaOptimo,
          ahorroPotencial: ahorroAgua > 0 ? ahorroAgua : 0
        })
      } else if (aguaRatio > 1.1) {
        results.push({
          area: "acueducto",
          icon: <Droplets className="h-6 w-6" />,
          title: "Acueducto (Agua) - Consumo Moderado",
          description: `Tu consumo mensual de ${formData.acueducto} m3 esta algo elevado (promedio: ${aguaAvg.toFixed(2)} m3/mes). Huella: ${aguaCO2.toFixed(1)} kg CO2/mes.`,
          tips: [
            "Cierra el grifo mientras te enjabonas o cepillas",
            "Usa lavadora y lavavajillas solo con carga completa"
          ],
          severity: "medium",
          costoActual: costoAguaActual,
          costoOptimo: costoAguaOptimo,
          ahorroPotencial: ahorroAgua > 0 ? ahorroAgua : 0
        })
      } else {
        results.push({
          area: "acueducto",
          icon: <Droplets className="h-6 w-6" />,
          title: "Acueducto (Agua) - Consumo Eficiente",
          description: `Excelente! Tu consumo mensual de ${formData.acueducto} m3 es eficiente (promedio: ${aguaAvg.toFixed(2)} m3/mes). Huella: ${aguaCO2.toFixed(1)} kg CO2/mes.`,
          tips: [
            "Sigue cuidando el agua como lo haces actualmente"
          ],
          severity: "low",
          costoActual: costoAguaActual,
          costoOptimo: costoAguaOptimo,
          ahorroPotencial: 0
        })
      }
    }

    // ========== ANALISIS DE ALCANTARILLADO ==========
    if (selectedServices.alcantarillado) {
      const alcAvg = CONSUMO_PROMEDIO.alcantarillado[estratoIndex]
      const alcRatio = formData.alcantarillado / alcAvg
      const costoAlcActual = calcularCostoAlcantarillado(formData.alcantarillado, formData.estrato)
      const costoAlcOptimo = calcularCostoAlcantarillado(alcAvg * 0.85, formData.estrato)
      const ahorroAlc = costoAlcActual - costoAlcOptimo

      if (alcRatio > 1.3) {
        results.push({
          area: "alcantarillado",
          icon: <Waves className="h-6 w-6" />,
          title: "Alcantarillado - Consumo Alto",
          description: `Tu consumo mensual de ${formData.alcantarillado} m3 esta ${Math.round((alcRatio - 1) * 100)}% por encima del promedio (${alcAvg.toFixed(2)} m3/mes).`,
          tips: [
            "Reduce el consumo de agua para disminuir automaticamente el alcantarillado",
            "Evita descargar residuos solidos por el desague",
            "Considera sistemas de recoleccion de agua lluvia"
          ],
          severity: "high",
          costoActual: costoAlcActual,
          costoOptimo: costoAlcOptimo,
          ahorroPotencial: ahorroAlc > 0 ? ahorroAlc : 0
        })
      } else if (alcRatio > 1.1) {
        results.push({
          area: "alcantarillado",
          icon: <Waves className="h-6 w-6" />,
          title: "Alcantarillado - Consumo Moderado",
          description: `Tu consumo mensual de ${formData.alcantarillado} m3 esta ligeramente elevado (promedio: ${alcAvg.toFixed(2)} m3/mes).`,
          tips: [
            "Optimiza el uso del agua para reducir vertimientos"
          ],
          severity: "medium",
          costoActual: costoAlcActual,
          costoOptimo: costoAlcOptimo,
          ahorroPotencial: ahorroAlc > 0 ? ahorroAlc : 0
        })
      } else {
        results.push({
          area: "alcantarillado",
          icon: <Waves className="h-6 w-6" />,
          title: "Alcantarillado - Consumo Normal",
          description: `Tu consumo mensual de ${formData.alcantarillado} m3 esta dentro del rango normal (${alcAvg.toFixed(2)} m3/mes).`,
          tips: [
            "Mantiene tu consumo actual de agua"
          ],
          severity: "low",
          costoActual: costoAlcActual,
          costoOptimo: costoAlcOptimo,
          ahorroPotencial: 0
        })
      }
    }

    results.sort((a, b) => {
      const order = { high: 0, medium: 1, low: 2 }
      return order[a.severity] - order[b.severity]
    })

    setRecommendations(results)
    setShowResults(true)
  }

  const getTotalCO2 = () => {
    let total = 0
    if (selectedServices.energia) total += formData.energia * CO2_FACTOR_ENERGIA
    if (selectedServices.gas) total += formData.gas * CO2_FACTOR_GAS
    if (selectedServices.acueducto) total += formData.acueducto * CO2_FACTOR_AGUA
    if (selectedServices.alcantarillado) total += formData.alcantarillado * CO2_FACTOR_AGUA
    return total
  }

  const getTotalCostoActual = () => {
    if (formData.estrato === 0) return 0
    let total = 0
    if (selectedServices.energia) total += calcularCostoEnergia(formData.energia, formData.estrato)
    if (selectedServices.gas) total += calcularCostoGas(formData.gas, formData.estrato)
    if (selectedServices.acueducto) total += calcularCostoAgua(formData.acueducto, formData.estrato)
    if (selectedServices.alcantarillado) total += calcularCostoAlcantarillado(formData.alcantarillado, formData.estrato)
    return total
  }

  const getTotalAhorroPotencial = () => {
    return recommendations.reduce((acc, rec) => acc + rec.ahorroPotencial, 0)
  }

  const handleSaveAnalysis = async () => {
    setIsSaving(true)
    setSaveMessage(null)
    const result = await saveConsumptionAnalysis({
      month: "Septiembre",
      year: 2026,
      estrato: formData.estrato,
      selectedServices: {
        energia: selectedServices.energia,
        gas: selectedServices.gas,
        acueducto: selectedServices.acueducto,
        alcantarillado: selectedServices.alcantarillado,
      },
      consumption: {
        energia: formData.energia,
        gas: formData.gas,
        acueducto: formData.acueducto,
        alcantarillado: formData.alcantarillado,
      },
      costs: {
        energia: calcularCostoEnergia(formData.energia, formData.estrato),
        gas: calcularCostoGas(formData.gas, formData.estrato),
        acueducto: calcularCostoAgua(formData.acueducto, formData.estrato),
        alcantarillado: calcularCostoAlcantarillado(formData.alcantarillado, formData.estrato),
      },
      co2: {
        energia: formData.energia * CO2_FACTOR_ENERGIA,
        gas: formData.gas * CO2_FACTOR_GAS,
        acueducto: formData.acueducto * CO2_FACTOR_AGUA,
        alcantarillado: formData.alcantarillado * CO2_FACTOR_AGUA,
      },
      totalCost: getTotalCostoActual(),
      totalCo2: getTotalCO2(),
    })
    setIsSaving(false)
    setSaveMessage(result.ok ? "Análisis guardado en tu cuenta." : "Inicia sesión para guardar este análisis.")
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high": return "border-red-500/50 bg-red-500/10"
      case "medium": return "border-yellow-500/50 bg-yellow-500/10"
      case "low": return "border-primary/50 bg-primary/10"
      default: return "border-border"
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "high": return <AlertTriangle className="h-5 w-5 text-red-500" />
      case "medium": return <TrendingDown className="h-5 w-5 text-yellow-500" />
      case "low": return <CheckCircle2 className="h-5 w-5 text-primary" />
      default: return null
    }
  }

  const resetForm = () => {
    setShowResults(false)
    setSaveMessage(null)
    setFormData({
      energia: 0,
      gas: 0,
      acueducto: 0,
      alcantarillado: 0,
      estrato: 0,
    })
    setSelectedServices({
      energia: true,
      gas: true,
      acueducto: true,
      alcantarillado: true,
    })
    setUploadedFile(null)
    setInputMode("manual")
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pb-20 pt-24">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back Button */}
          <Link href="/" className="mb-8 inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-foreground">
            <ArrowLeft className="h-4 w-4" />
            Volver al inicio
          </Link>

          {/* Title */}
          <div className="mb-10 text-center">
            <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Calculadora de Consumo
            </h1>
            <p className="mt-3 text-lg text-muted-foreground">
              Ingresa los datos de tu factura de servicios para obtener un analisis personalizado con costos reales de Medellín (tarifas EPM septiembre 2026).
            </p>
          </div>

          {!showResults ? (
            <div className="space-y-6">
              {/* Service Selection */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle>Selecciona los Servicios a Analizar</CardTitle>
                  <CardDescription>
                    Puedes elegir uno, varios o todos los servicios para calcular precios y CO2 individualmente
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    <div
                      onClick={() => handleServiceToggle("energia")}
                      className={`flex cursor-pointer items-center gap-3 rounded-lg border-2 p-4 transition-all ${
                        selectedServices.energia
                          ? "border-yellow-500 bg-yellow-500/10"
                          : "border-border hover:border-yellow-500/50"
                      }`}
                    >
                      <Checkbox
                        checked={selectedServices.energia}
                        onCheckedChange={() => handleServiceToggle("energia")}
                        className="border-yellow-500 data-[state=checked]:bg-yellow-500"
                      />
                      <div className="flex items-center gap-2">
                        <Zap className="h-5 w-5 text-yellow-500" />
                        <span className="font-medium text-foreground">Luz</span>
                      </div>
                    </div>

                    <div
                      onClick={() => handleServiceToggle("gas")}
                      className={`flex cursor-pointer items-center gap-3 rounded-lg border-2 p-4 transition-all ${
                        selectedServices.gas
                          ? "border-orange-500 bg-orange-500/10"
                          : "border-border hover:border-orange-500/50"
                      }`}
                    >
                      <Checkbox
                        checked={selectedServices.gas}
                        onCheckedChange={() => handleServiceToggle("gas")}
                        className="border-orange-500 data-[state=checked]:bg-orange-500"
                      />
                      <div className="flex items-center gap-2">
                        <Flame className="h-5 w-5 text-orange-500" />
                        <span className="font-medium text-foreground">Gas</span>
                      </div>
                    </div>

                    <div
                      onClick={() => handleServiceToggle("acueducto")}
                      className={`flex cursor-pointer items-center gap-3 rounded-lg border-2 p-4 transition-all ${
                        selectedServices.acueducto
                          ? "border-blue-500 bg-blue-500/10"
                          : "border-border hover:border-blue-500/50"
                      }`}
                    >
                      <Checkbox
                        checked={selectedServices.acueducto}
                        onCheckedChange={() => handleServiceToggle("acueducto")}
                        className="border-blue-500 data-[state=checked]:bg-blue-500"
                      />
                      <div className="flex items-center gap-2">
                        <Droplets className="h-5 w-5 text-blue-500" />
                        <span className="font-medium text-foreground">Agua</span>
                      </div>
                    </div>

                    <div
                      onClick={() => handleServiceToggle("alcantarillado")}
                      className={`flex cursor-pointer items-center gap-3 rounded-lg border-2 p-4 transition-all ${
                        selectedServices.alcantarillado
                          ? "border-cyan-500 bg-cyan-500/10"
                          : "border-border hover:border-cyan-500/50"
                      }`}
                    >
                      <Checkbox
                        checked={selectedServices.alcantarillado}
                        onCheckedChange={() => handleServiceToggle("alcantarillado")}
                        className="border-cyan-500 data-[state=checked]:bg-cyan-500"
                      />
                      <div className="flex items-center gap-2">
                        <Waves className="h-5 w-5 text-cyan-500" />
                        <span className="font-medium text-foreground">Alcantarillado</span>
                      </div>
                    </div>
                  </div>
                  <p className="mt-4 text-center text-sm text-muted-foreground">
                    {getSelectedCount()} de 4 servicios seleccionados
                  </p>
                </CardContent>
              </Card>

              {/* Input Mode Selection */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle>Metodo de Ingreso de Datos</CardTitle>
                  <CardDescription>
                    Elige como deseas ingresar la informacion de tu factura
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <button
                      onClick={() => setInputMode("manual")}
                      className={`flex flex-col items-center gap-3 rounded-lg border-2 p-6 transition-all ${
                        inputMode === "manual" 
                          ? "border-primary bg-primary/10" 
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <div className={`rounded-full p-3 ${inputMode === "manual" ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>
                        <Zap className="h-6 w-6" />
                      </div>
                      <div className="text-center">
                        <p className="font-semibold text-foreground">Ingreso Manual</p>
                        <p className="mt-1 text-sm text-muted-foreground">
                          Digita los valores manualmente
                        </p>
                      </div>
                    </button>

                    <button
                      onClick={() => setInputMode("upload")}
                      className={`flex flex-col items-center gap-3 rounded-lg border-2 p-6 transition-all ${
                        inputMode === "upload" 
                          ? "border-primary bg-primary/10" 
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <div className={`rounded-full p-3 ${inputMode === "upload" ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>
                        <Upload className="h-6 w-6" />
                      </div>
                      <div className="text-center">
                        <p className="font-semibold text-foreground">Subir Factura PDF</p>
                        <p className="mt-1 text-sm text-muted-foreground">
                          Carga tu factura y extraemos los datos
                        </p>
                      </div>
                    </button>
                  </div>
                </CardContent>
              </Card>

              {/* Upload Section */}
              {inputMode === "upload" && (
                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Upload className="h-5 w-5 text-primary" />
                      Cargar Factura de Servicios
                    </CardTitle>
                    <CardDescription>
                      Sube tu factura en formato PDF. Funciona con facturas de EPM y Aguas Regionales.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {!uploadedFile ? (
                      <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-border p-8 transition-colors hover:border-primary/50">
                        <FileText className="mb-4 h-12 w-12 text-muted-foreground" />
                        <p className="mb-2 text-sm font-medium text-foreground">
                          Arrastra tu factura aqui o haz clic para seleccionar
                        </p>
                        <p className="mb-4 text-xs text-muted-foreground">
                          Solo archivos PDF (max. 10MB)
                        </p>
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept=".pdf"
                          onChange={handleFileUpload}
                          className="hidden"
                          id="file-upload"
                        />
                        <label htmlFor="file-upload">
                          <Button variant="outline" className="cursor-pointer" asChild>
                            <span>Seleccionar archivo</span>
                          </Button>
                        </label>
                      </div>
                    ) : (
                      <div className="rounded-lg border border-border bg-secondary/30 p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="rounded-lg bg-primary/20 p-2">
                              <FileText className="h-6 w-6 text-primary" />
                            </div>
                            <div>
                              <p className="font-medium text-foreground">{uploadedFile.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {(uploadedFile.size / 1024).toFixed(1)} KB
                              </p>
                            </div>
                          </div>
                          {!isProcessing && (
                            <Button variant="ghost" size="icon" onClick={removeFile}>
                              <X className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                        
                        {isProcessing && (
                          <div className="mt-4 flex items-center gap-3 rounded-lg bg-primary/10 p-3">
                            <Loader2 className="h-5 w-5 animate-spin text-primary" />
                            <div>
                              <p className="font-medium text-foreground">Procesando factura...</p>
                              <p className="text-sm text-muted-foreground">
                                Extrayendo datos de consumo
                              </p>
                            </div>
                          </div>
                        )}

                        {!isProcessing && formData.estrato > 0 && (
                          <div className="mt-4 rounded-lg bg-primary/10 p-3">
                            <p className="flex items-center gap-2 font-medium text-primary">
                              <CheckCircle2 className="h-5 w-5" />
                              Datos extraidos correctamente
                            </p>
                            <p className="mt-1 text-sm text-muted-foreground">
                              Revisa los valores y ajustalos si es necesario
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Manual Input Form */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle>
                    {inputMode === "upload" && uploadedFile && !isProcessing 
                      ? "Datos Extraidos - Verifica y Ajusta" 
                      : "Datos de Consumo Mensual"}
                  </CardTitle>
                  <CardDescription>
                    Ingresa los valores de tu factura del ultimo mes. Solo se mostraran los servicios que seleccionaste.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Estrato Selection */}
                  <div className="space-y-2">
                    <Label htmlFor="estrato">Seleccione su Estrato Socioeconomico</Label>
                    <Select value={formData.estrato > 0 ? formData.estrato.toString() : ""} onValueChange={handleEstratoChange}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Seleccione estrato (1-6)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Estrato 1 - Bajo-bajo</SelectItem>
                        <SelectItem value="2">Estrato 2 - Bajo</SelectItem>
                        <SelectItem value="3">Estrato 3 - Medio-bajo</SelectItem>
                        <SelectItem value="4">Estrato 4 - Medio</SelectItem>
                        <SelectItem value="5">Estrato 5 - Medio-alto</SelectItem>
                        <SelectItem value="6">Estrato 6 - Alto</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      El estrato determina los subsidios y contribuciones
                    </p>
                  </div>

                  {/* Consumption Inputs - Only show selected services */}
                  <div className="grid gap-6 sm:grid-cols-2">
                    {selectedServices.energia && (
                      <div className="space-y-2">
                        <Label htmlFor="energia" className="flex items-center gap-2">
                          <Zap className="h-4 w-4 text-yellow-500" />
                          Energia Electrica (kWh/mes)
                        </Label>
                        <Input
                          id="energia"
                          type="number"
                          placeholder="Ej: 180"
                          min="0"
                          value={formData.energia || ""}
                          onChange={(e) => handleInputChange("energia", e.target.value)}
                          className="bg-input"
                        />
                        <p className="text-xs text-muted-foreground">
                          Kilovatios hora consumidos en el mes
                        </p>
                      </div>
                    )}

                    {selectedServices.gas && (
                      <div className="space-y-2">
                        <Label htmlFor="gas" className="flex items-center gap-2">
                          <Flame className="h-4 w-4 text-orange-500" />
                          Gas Natural (m3/mes)
                        </Label>
                        <Input
                          id="gas"
                          type="number"
                          placeholder="Ej: 22"
                          min="0"
                          value={formData.gas || ""}
                          onChange={(e) => handleInputChange("gas", e.target.value)}
                          className="bg-input"
                        />
                        <p className="text-xs text-muted-foreground">
                          Metros cubicos de gas consumidos
                        </p>
                      </div>
                    )}

                    {selectedServices.acueducto && (
                      <div className="space-y-2">
                        <Label htmlFor="acueducto" className="flex items-center gap-2">
                          <Droplets className="h-4 w-4 text-blue-500" />
                          Acueducto - Agua (m3/mes)
                        </Label>
                        <Input
                          id="acueducto"
                          type="number"
                          placeholder="Ej: 12"
                          min="0"
                          value={formData.acueducto || ""}
                          onChange={(e) => handleInputChange("acueducto", e.target.value)}
                          className="bg-input"
                        />
                        <p className="text-xs text-muted-foreground">
                          Metros cubicos de agua consumidos
                        </p>
                      </div>
                    )}

                    {selectedServices.alcantarillado && (
                      <div className="space-y-2">
                        <Label htmlFor="alcantarillado" className="flex items-center gap-2">
                          <Waves className="h-4 w-4 text-cyan-500" />
                          Alcantarillado (m3/mes)
                        </Label>
                        <Input
                          id="alcantarillado"
                          type="number"
                          placeholder="Ej: 10"
                          min="0"
                          value={formData.alcantarillado || ""}
                          onChange={(e) => handleInputChange("alcantarillado", e.target.value)}
                          className="bg-input"
                        />
                        <p className="text-xs text-muted-foreground">
                          Metros cubicos de vertimientos
                        </p>
                      </div>
                    )}
                  </div>

                  {getSelectedCount() === 0 && (
                    <div className="rounded-lg border border-yellow-500/50 bg-yellow-500/10 p-4 text-center">
                      <p className="text-sm text-yellow-600 dark:text-yellow-400">
                        Selecciona al menos un servicio arriba para continuar
                      </p>
                    </div>
                  )}

                  <Button 
                    onClick={analyzeConsumption} 
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                    size="lg"
                    disabled={isProcessing || getSelectedCount() === 0}
                  >
                    Analizar Consumo y Calcular Costos
                  </Button>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="space-y-8">
              {/* Summary Card */}
              <Card className="border-primary/30 bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-primary" />
                    Resumen de Consumo Mensual - Estrato {formData.estrato}
                  </CardTitle>
                  <CardDescription>
                    Servicios analizados: {getSelectedCount()} de 4
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    {selectedServices.energia && (
                      <div className="rounded-lg border border-yellow-500/30 bg-yellow-500/5 p-4 text-center">
                        <Zap className="mx-auto h-6 w-6 text-yellow-500" />
                        <p className="mt-2 text-2xl font-bold text-foreground">{formData.energia}</p>
                        <p className="text-sm text-muted-foreground">kWh/mes</p>
                        <p className="mt-1 text-xs font-medium text-yellow-600 dark:text-yellow-400">{formatCurrency(calcularCostoEnergia(formData.energia, formData.estrato))}</p>
                      </div>
                    )}
                    {selectedServices.gas && (
                      <div className="rounded-lg border border-orange-500/30 bg-orange-500/5 p-4 text-center">
                        <Flame className="mx-auto h-6 w-6 text-orange-500" />
                        <p className="mt-2 text-2xl font-bold text-foreground">{formData.gas}</p>
                        <p className="text-sm text-muted-foreground">m3/mes Gas</p>
                        <p className="mt-1 text-xs font-medium text-orange-600 dark:text-orange-400">{formatCurrency(calcularCostoGas(formData.gas, formData.estrato))}</p>
                      </div>
                    )}
                    {selectedServices.acueducto && (
                      <div className="rounded-lg border border-blue-500/30 bg-blue-500/5 p-4 text-center">
                        <Droplets className="mx-auto h-6 w-6 text-blue-500" />
                        <p className="mt-2 text-2xl font-bold text-foreground">{formData.acueducto}</p>
                        <p className="text-sm text-muted-foreground">m3/mes Agua</p>
                        <p className="mt-1 text-xs font-medium text-blue-600 dark:text-blue-400">{formatCurrency(calcularCostoAgua(formData.acueducto, formData.estrato))}</p>
                      </div>
                    )}
                    {selectedServices.alcantarillado && (
                      <div className="rounded-lg border border-cyan-500/30 bg-cyan-500/5 p-4 text-center">
                        <Waves className="mx-auto h-6 w-6 text-cyan-500" />
                        <p className="mt-2 text-2xl font-bold text-foreground">{formData.alcantarillado}</p>
                        <p className="text-sm text-muted-foreground">m3/mes Alcant.</p>
                        <p className="mt-1 text-xs font-medium text-cyan-600 dark:text-cyan-400">{formatCurrency(calcularCostoAlcantarillado(formData.alcantarillado, formData.estrato))}</p>
                      </div>
                    )}
                  </div>

                  {/* Total Cost and Savings */}
                  <div className="mt-6 grid gap-4 sm:grid-cols-3">
                    <div className="rounded-lg border border-border bg-secondary/50 p-4 text-center">
                      <DollarSign className="mx-auto h-6 w-6 text-foreground" />
                      <p className="mt-1 text-sm text-muted-foreground">Costo Total Mensual</p>
                      <p className="text-2xl font-bold text-foreground">{formatCurrency(getTotalCostoActual())}</p>
                    </div>
                    <div className={`rounded-lg border p-4 text-center ${getTotalAhorroPotencial() > 0 ? 'border-primary/50 bg-primary/10' : 'border-border bg-secondary/50'}`}>
                      <TrendingDown className={`mx-auto h-6 w-6 ${getTotalAhorroPotencial() > 0 ? 'text-primary' : 'text-muted-foreground'}`} />
                      <p className="mt-1 text-sm text-muted-foreground">Ahorro Potencial</p>
                      <p className={`text-2xl font-bold ${getTotalAhorroPotencial() > 0 ? 'text-primary' : 'text-foreground'}`}>
                        {formatCurrency(getTotalAhorroPotencial())}
                      </p>
                    </div>
                    <div className="rounded-lg border border-border bg-secondary/50 p-4 text-center">
                      <Lightbulb className="mx-auto h-6 w-6 text-foreground" />
                      <p className="mt-1 text-sm text-muted-foreground">Huella CO2 Mensual</p>
                      <p className="text-2xl font-bold text-foreground">{getTotalCO2().toFixed(1)} kg</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Recommendations */}
              <div className="space-y-4">
                <h2 className="text-xl font-bold text-foreground">Analisis y Recomendaciones</h2>
                {recommendations.map((rec, index) => (
                  <Card key={index} className={`border-2 ${getSeverityColor(rec.severity)}`}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className="rounded-lg bg-secondary p-2 text-foreground">
                            {rec.icon}
                          </div>
                          <div>
                            <CardTitle className="text-lg">{rec.title}</CardTitle>
                            <div className="mt-1 flex items-center gap-4 text-sm">
                              <span className="text-muted-foreground">
                                Costo actual: <span className="font-semibold text-foreground">{formatCurrency(rec.costoActual)}</span>
                              </span>
                              {rec.ahorroPotencial > 0 && (
                                <span className="text-primary">
                                  Ahorro posible: {formatCurrency(rec.ahorroPotencial)}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        {getSeverityIcon(rec.severity)}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-muted-foreground">{rec.description}</p>
                      <div>
                        <p className="mb-2 font-semibold text-foreground">Recomendaciones:</p>
                        <ul className="space-y-2">
                          {rec.tips.map((tip, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                              {tip}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Save analysis for authenticated users */}
              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="flex flex-col items-center gap-3 p-5 text-center sm:flex-row sm:justify-between sm:text-left">
                  <div>
                    <p className="font-semibold text-foreground">Guarda este análisis</p>
                    <p className="text-sm text-muted-foreground">
                      Conserva los datos de septiembre de 2026 en tu historial personal.
                    </p>
                    {saveMessage && <p className="mt-2 text-sm font-medium text-primary">{saveMessage}</p>}
                  </div>
                  <Button onClick={handleSaveAnalysis} disabled={isSaving} className="shrink-0">
                    {isSaving ? "Guardando..." : "Guardar en mi cuenta"}
                  </Button>
                </CardContent>
              </Card>

              {/* New Calculation Button */}
              <div className="flex justify-center">
                <Button onClick={resetForm} size="lg" variant="outline">
                  Realizar Nuevo Calculo
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
