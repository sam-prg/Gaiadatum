'use server'

import { headers } from 'next/headers'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { consumptionAnalysis } from '@/lib/db/schema'
import { desc, eq } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'

export async function saveConsumptionAnalysis(input: {
  month: string
  year: number
  estrato: number
  selectedServices: Record<string, boolean>
  consumption: Record<string, number>
  costs: Record<string, number>
  co2: Record<string, number>
  totalCost: number
  totalCo2: number
}) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user?.id) return { ok: false as const, reason: 'UNAUTHENTICATED' as const }

  const id = crypto.randomUUID()
  await db.insert(consumptionAnalysis).values({
    id,
    userId: session.user.id,
    month: input.month,
    year: input.year,
    estrato: input.estrato,
    selectedServices: input.selectedServices,
    consumption: input.consumption,
    costs: input.costs,
    co2: input.co2,
    totalCost: Math.round(input.totalCost),
    totalCo2: input.totalCo2,
  })
  revalidatePath('/perfil')
  return { ok: true as const, id }
}

export async function getConsumptionAnalyses() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user?.id) return []

  return db
    .select()
    .from(consumptionAnalysis)
    .where(eq(consumptionAnalysis.userId, session.user.id))
    .orderBy(desc(consumptionAnalysis.createdAt))
}
