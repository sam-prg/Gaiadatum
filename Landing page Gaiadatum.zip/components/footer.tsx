import Link from "next/link"
import { Leaf, Github, Linkedin, Mail } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-border bg-card py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
                <Leaf className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">GaiaDatum</span>
            </Link>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
              Sistema inteligente para el análisis del consumo energético y reducción 
              de la huella de carbono.
            </p>
          </div>

          {/* Links */}
          <div>
            <h3 className="mb-4 font-semibold text-foreground">Navegación</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#desafio" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                  Desafío
                </Link>
              </li>
              <li>
                <Link href="#solucion" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                  Solución
                </Link>
              </li>
              <li>
                <Link href="#caracteristicas" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                  Características
                </Link>
              </li>
              <li>
                <Link href="#impacto" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                  Impacto
                </Link>
              </li>
            </ul>
          </div>

          {/* Project Info */}
          <div>
            <h3 className="mb-4 font-semibold text-foreground">Proyecto</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Corporación Universitaria Lasallista</li>
              <li>Semilleros: Dedalos y Tecnovadora</li>
              <li>Ingeniería Informática</li>
              <li>RedCOLSI - Antioquia</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="mb-4 font-semibold text-foreground">Contacto</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="mailto:jgallego35@unilasallista.edu.co"
                  className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
                >
                  <Mail className="h-4 w-4" />
                  Jaider Gallego
                </a>
              </li>
              <li>
                <a
                  href="mailto:sherrera88@unilasallista.edu.co"
                  className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
                >
                  <Mail className="h-4 w-4" />
                  Samuel Herrera
                </a>
              </li>
              <li>
                <a
                  href="mailto:svilla1@unilasallista.edu.co"
                  className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
                >
                  <Mail className="h-4 w-4" />
                  Samuel Villa
                </a>
              </li>
            </ul>
            <div className="mt-4 flex gap-4">
              <a
                href="#"
                className="text-muted-foreground transition-colors hover:text-foreground"
                aria-label="GitHub"
              >
                <Github className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="text-muted-foreground transition-colors hover:text-foreground"
                aria-label="LinkedIn"
              >
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-border pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} GaiaDatum. Proyecto de investigación - Corporación Universitaria Lasallista.
          </p>
        </div>
      </div>
    </footer>
  )
}
