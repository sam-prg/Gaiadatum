"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X, Leaf } from "lucide-react"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <Leaf className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold text-foreground">GaiaDatum</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link href="#desafio" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Desafío
          </Link>
          <Link href="#solucion" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Solución
          </Link>
          <Link href="#caracteristicas" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Características
          </Link>
          <Link href="#impacto" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
            Impacto
          </Link>
        </nav>

        <div className="hidden items-center gap-4 md:flex">
          <Button variant="ghost" className="text-muted-foreground hover:text-foreground">
            Contacto
          </Button>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
            Comenzar
          </Button>
        </div>

        <button
          className="md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? (
            <X className="h-6 w-6 text-foreground" />
          ) : (
            <Menu className="h-6 w-6 text-foreground" />
          )}
        </button>
      </div>

      {isMenuOpen && (
        <div className="border-t border-border bg-background md:hidden">
          <nav className="flex flex-col gap-4 px-4 py-6">
            <Link
              href="#desafio"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              onClick={() => setIsMenuOpen(false)}
            >
              Desafío
            </Link>
            <Link
              href="#solucion"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              onClick={() => setIsMenuOpen(false)}
            >
              Solución
            </Link>
            <Link
              href="#caracteristicas"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              onClick={() => setIsMenuOpen(false)}
            >
              Características
            </Link>
            <Link
              href="#impacto"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              onClick={() => setIsMenuOpen(false)}
            >
              Impacto
            </Link>
            <div className="flex flex-col gap-2 pt-4">
              <Button variant="ghost" className="w-full justify-start text-muted-foreground">
                Contacto
              </Button>
              <Button className="w-full bg-primary text-primary-foreground">
                Comenzar
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
