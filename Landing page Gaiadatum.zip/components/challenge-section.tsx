import { AlertTriangle, EyeOff, Footprints, TrendingDown } from "lucide-react"

const challenges = [
  {
    icon: AlertTriangle,
    title: "Consumo Energético",
    description: "El consumo energético en entornos universitarios es elevado debido al uso constante de equipos tecnológicos, iluminación y otros sistemas eléctricos.",
  },
  {
    icon: EyeOff,
    title: "Falta de Monitoreo",
    description: "No se cuenta con herramientas que permitan monitorear el consumo en tiempo real ni analizarlo de manera detallada.",
  },
  {
    icon: Footprints,
    title: "Huella de Carbono",
    description: "Bajo nivel de conciencia sobre la huella de carbono que producen las actividades cotidianas como encender computadores o dejar luces encendidas.",
  },
  {
    icon: TrendingDown,
    title: "Limitada Toma de Decisiones",
    description: "Se limita la toma de decisiones sostenibles y el uso eficiente de los recursos energéticos dentro de la institución.",
  },
]

export function ChallengeSection() {
  return (
    <section id="desafio" className="border-t border-border bg-secondary/30 py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-16 text-center">
          <span className="mb-4 inline-block rounded-full bg-destructive/10 px-4 py-1.5 text-sm font-medium text-destructive">
            Desafío a Resolver
          </span>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl md:text-5xl">
            El problema que enfrentamos
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-muted-foreground">
            En un mundo donde el consumo energético crece cada día, la mayoría de las personas 
            no es consciente del impacto ambiental que generan sus actividades cotidianas.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {challenges.map((challenge, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-destructive/10 transition-colors group-hover:bg-primary/20">
                <challenge.icon className="h-6 w-6 text-destructive transition-colors group-hover:text-primary" />
              </div>
              <h3 className="mb-2 text-lg font-semibold text-foreground">{challenge.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{challenge.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
