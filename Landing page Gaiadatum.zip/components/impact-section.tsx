import { TrendingUp, Users, Recycle, Sparkles } from "lucide-react"

const impacts = [
  {
    icon: TrendingUp,
    title: "Reducción de Emisiones",
    description: "El uso de tecnología para medir el consumo energético facilita la reducción de emisiones y promueve la sostenibilidad.",
    stat: "CO₂",
    statLabel: "Huella medible",
  },
  {
    icon: Users,
    title: "Conciencia Ambiental",
    description: "Se espera disminuir el desperdicio de energía y crear conciencia ambiental en los usuarios.",
    stat: "100%",
    statLabel: "Transparencia",
  },
  {
    icon: Recycle,
    title: "Uso Eficiente",
    description: "Optimización de recursos energéticos dentro de hogares e instituciones educativas.",
    stat: "24/7",
    statLabel: "Monitoreo activo",
  },
  {
    icon: Sparkles,
    title: "Escalabilidad",
    description: "GaiaDatum puede ampliarse integrando inteligencia artificial y conexión con dispositivos inteligentes.",
    stat: "IA",
    statLabel: "Integración futura",
  },
]

export function ImpactSection() {
  return (
    <section id="impacto" className="border-t border-border py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-16 text-center">
          <span className="mb-4 inline-block rounded-full bg-chart-4/10 px-4 py-1.5 text-sm font-medium text-chart-4">
            Impacto y Proyecciones
          </span>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl md:text-5xl">
            Construyendo un futuro sostenible
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-muted-foreground">
            El proyecto GaiaDatum propone una solución innovadora que puede generar un impacto 
            positivo tanto en hogares como en instituciones.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {impacts.map((impact, index) => (
            <div
              key={index}
              className="group flex flex-col rounded-2xl border border-border bg-card p-6 transition-all hover:border-primary/50"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <impact.icon className="h-6 w-6 text-primary" />
              </div>
              <div className="mb-4">
                <span className="text-3xl font-bold text-primary">{impact.stat}</span>
                <span className="ml-2 text-sm text-muted-foreground">{impact.statLabel}</span>
              </div>
              <h3 className="mb-2 text-lg font-semibold text-foreground">{impact.title}</h3>
              <p className="flex-1 text-sm leading-relaxed text-muted-foreground">{impact.description}</p>
            </div>
          ))}
        </div>

        {/* Conclusion Card */}
        <div className="mt-16 rounded-2xl border border-primary/30 bg-primary/5 p-8 sm:p-10">
          <div className="mx-auto max-w-3xl text-center">
            <h3 className="mb-4 text-2xl font-bold text-foreground sm:text-3xl">
              Conclusión Principal
            </h3>
            <p className="text-pretty text-lg leading-relaxed text-muted-foreground">
              GaiaDatum demuestra la viabilidad de integrar tecnologías como IoT y análisis 
              de datos en soluciones aplicadas, generando una herramienta funcional que puede 
              ser <span className="font-semibold text-primary">escalable y replicable</span> en 
              otros entornos educativos, contribuyendo a la construcción de un futuro más sostenible.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
