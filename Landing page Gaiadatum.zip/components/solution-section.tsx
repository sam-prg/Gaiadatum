import { Activity, Database, Brain, Leaf, Clock } from "lucide-react"

const features = [
  {
    icon: Clock,
    title: "Monitoreo en Tiempo Real",
    description: "Visualiza el consumo energético de tus espacios en tiempo real con actualizaciones constantes.",
  },
  {
    icon: Database,
    title: "Recolección de Datos IoT",
    description: "Sensores IoT integrados que recolectan y almacenan datos de consumo de manera automática.",
  },
  {
    icon: Brain,
    title: "Análisis Inteligente",
    description: "Algoritmos predictivos que identifican patrones de uso y detectan ineficiencias energéticas.",
  },
  {
    icon: Leaf,
    title: "Cálculo de Huella de Carbono",
    description: "Calcula automáticamente el CO₂ asociado a tu consumo energético y mide tu impacto ambiental.",
  },
  {
    icon: Activity,
    title: "Decisiones Sostenibles",
    description: "Recomendaciones personalizadas para optimizar el uso de energía y reducir tu huella.",
  },
]

export function SolutionSection() {
  return (
    <section id="solucion" className="border-t border-border py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <div>
            <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
              Solución Propuesta
            </span>
            <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl md:text-5xl">
              GaiaDatum: Plataforma inteligente de monitoreo energético
            </h2>
            <p className="mt-6 text-pretty text-lg leading-relaxed text-muted-foreground">
              Una plataforma innovadora que integra tecnología IoT y análisis de datos para 
              transformar información en conocimiento útil, permitiendo tomar decisiones más 
              responsables con el medio ambiente.
            </p>
            <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
              Más que una herramienta tecnológica, GaiaDatum busca crear conciencia, optimizar 
              recursos y contribuir activamente a la reducción del impacto ambiental, demostrando 
              cómo la ingeniería informática puede ser parte clave en la construcción de un 
              futuro más sostenible.
            </p>
          </div>

          <div className="grid gap-4">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group flex items-start gap-4 rounded-xl border border-border bg-card/50 p-4 transition-all hover:border-primary/50 hover:bg-card"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 transition-colors group-hover:bg-primary/20">
                  <feature.icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{feature.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
