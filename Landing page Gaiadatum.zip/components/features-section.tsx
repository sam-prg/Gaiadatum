"use client"

import { Cpu, BarChart2, CloudLightning, LineChart, Target, Lightbulb } from "lucide-react"

const features = [
  {
    icon: Cpu,
    title: "Internet de las Cosas",
    description: "Sensores IoT de última generación para la recolección automática de datos de consumo energético.",
    highlight: "IoT Integrado",
  },
  {
    icon: BarChart2,
    title: "Análisis de Datos",
    description: "Procesamiento inteligente de información para identificar patrones y oportunidades de mejora.",
    highlight: "Big Data",
  },
  {
    icon: CloudLightning,
    title: "Tiempo Real",
    description: "Monitoreo continuo con visualización instantánea del consumo energético actual.",
    highlight: "Live Data",
  },
  {
    icon: LineChart,
    title: "Predicción",
    description: "Modelos predictivos que estiman el consumo futuro y detectan anomalías de uso.",
    highlight: "Machine Learning",
  },
  {
    icon: Target,
    title: "Eficiencia",
    description: "Identificación de desperdicios y recomendaciones para optimizar el uso de energía.",
    highlight: "Optimización",
  },
  {
    icon: Lightbulb,
    title: "Conciencia Ambiental",
    description: "Visualización clara de tu impacto ambiental para fomentar hábitos responsables.",
    highlight: "Sostenibilidad",
  },
]

export function FeaturesSection() {
  return (
    <section id="caracteristicas" className="border-t border-border bg-secondary/30 py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-16 text-center">
          <span className="mb-4 inline-block rounded-full bg-accent/10 px-4 py-1.5 text-sm font-medium text-accent">
            Características
          </span>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl md:text-5xl">
            Tecnología al servicio del planeta
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-muted-foreground">
            GaiaDatum combina las últimas tecnologías en IoT, análisis de datos e inteligencia 
            artificial para ofrecer una solución integral de monitoreo energético.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5"
            >
              <div className="mb-2 inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                {feature.highlight}
              </div>
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-secondary transition-colors group-hover:bg-primary/20">
                <feature.icon className="h-7 w-7 text-muted-foreground transition-colors group-hover:text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-semibold text-foreground">{feature.title}</h3>
              <p className="leading-relaxed text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
